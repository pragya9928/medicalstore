﻿namespace WindowsFormsApplication1
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Report));
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.medIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mednameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companynameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expirydateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinedetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet9 = new WindowsFormsApplication1.MedDataDataSet9();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.custidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custaddrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custphoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custbloodgroupDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet10 = new WindowsFormsApplication1.MedDataDataSet10();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.medicine_detailTableAdapter = new WindowsFormsApplication1.MedDataDataSet9TableAdapters.Medicine_detailTableAdapter();
            this.customerTableAdapter = new WindowsFormsApplication1.MedDataDataSet10TableAdapters.customerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet10)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(431, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 34);
            this.label2.TabIndex = 6;
            this.label2.Text = "REPORT";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.medIdDataGridViewTextBoxColumn,
            this.mednameDataGridViewTextBoxColumn,
            this.companynameDataGridViewTextBoxColumn,
            this.manufacturedateDataGridViewTextBoxColumn,
            this.expirydateDataGridViewTextBoxColumn,
            this.medicinepriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.medicinedetailBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(216, 160);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(541, 150);
            this.dataGridView1.TabIndex = 7;
            // 
            // medIdDataGridViewTextBoxColumn
            // 
            this.medIdDataGridViewTextBoxColumn.DataPropertyName = "med_Id";
            this.medIdDataGridViewTextBoxColumn.HeaderText = "med_Id";
            this.medIdDataGridViewTextBoxColumn.Name = "medIdDataGridViewTextBoxColumn";
            // 
            // mednameDataGridViewTextBoxColumn
            // 
            this.mednameDataGridViewTextBoxColumn.DataPropertyName = "med_name";
            this.mednameDataGridViewTextBoxColumn.HeaderText = "med_name";
            this.mednameDataGridViewTextBoxColumn.Name = "mednameDataGridViewTextBoxColumn";
            // 
            // companynameDataGridViewTextBoxColumn
            // 
            this.companynameDataGridViewTextBoxColumn.DataPropertyName = "company_name";
            this.companynameDataGridViewTextBoxColumn.HeaderText = "company_name";
            this.companynameDataGridViewTextBoxColumn.Name = "companynameDataGridViewTextBoxColumn";
            // 
            // manufacturedateDataGridViewTextBoxColumn
            // 
            this.manufacturedateDataGridViewTextBoxColumn.DataPropertyName = "manufacture_date";
            this.manufacturedateDataGridViewTextBoxColumn.HeaderText = "manufacture_date";
            this.manufacturedateDataGridViewTextBoxColumn.Name = "manufacturedateDataGridViewTextBoxColumn";
            // 
            // expirydateDataGridViewTextBoxColumn
            // 
            this.expirydateDataGridViewTextBoxColumn.DataPropertyName = "expiry_date";
            this.expirydateDataGridViewTextBoxColumn.HeaderText = "expiry_date";
            this.expirydateDataGridViewTextBoxColumn.Name = "expirydateDataGridViewTextBoxColumn";
            // 
            // medicinepriceDataGridViewTextBoxColumn
            // 
            this.medicinepriceDataGridViewTextBoxColumn.DataPropertyName = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.HeaderText = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.Name = "medicinepriceDataGridViewTextBoxColumn";
            // 
            // medicinedetailBindingSource
            // 
            this.medicinedetailBindingSource.DataMember = "Medicine_detail";
            this.medicinedetailBindingSource.DataSource = this.medDataDataSet9;
            // 
            // medDataDataSet9
            // 
            this.medDataDataSet9.DataSetName = "MedDataDataSet9";
            this.medDataDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.custidDataGridViewTextBoxColumn,
            this.custnameDataGridViewTextBoxColumn,
            this.custaddrDataGridViewTextBoxColumn,
            this.custphoneDataGridViewTextBoxColumn,
            this.custbloodgroupDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.customerBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(216, 380);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(541, 150);
            this.dataGridView2.TabIndex = 8;
            // 
            // custidDataGridViewTextBoxColumn
            // 
            this.custidDataGridViewTextBoxColumn.DataPropertyName = "cust_id";
            this.custidDataGridViewTextBoxColumn.HeaderText = "cust_id";
            this.custidDataGridViewTextBoxColumn.Name = "custidDataGridViewTextBoxColumn";
            // 
            // custnameDataGridViewTextBoxColumn
            // 
            this.custnameDataGridViewTextBoxColumn.DataPropertyName = "cust_name";
            this.custnameDataGridViewTextBoxColumn.HeaderText = "cust_name";
            this.custnameDataGridViewTextBoxColumn.Name = "custnameDataGridViewTextBoxColumn";
            // 
            // custaddrDataGridViewTextBoxColumn
            // 
            this.custaddrDataGridViewTextBoxColumn.DataPropertyName = "cust_addr";
            this.custaddrDataGridViewTextBoxColumn.HeaderText = "cust_addr";
            this.custaddrDataGridViewTextBoxColumn.Name = "custaddrDataGridViewTextBoxColumn";
            // 
            // custphoneDataGridViewTextBoxColumn
            // 
            this.custphoneDataGridViewTextBoxColumn.DataPropertyName = "cust_phone";
            this.custphoneDataGridViewTextBoxColumn.HeaderText = "cust_phone";
            this.custphoneDataGridViewTextBoxColumn.Name = "custphoneDataGridViewTextBoxColumn";
            // 
            // custbloodgroupDataGridViewTextBoxColumn
            // 
            this.custbloodgroupDataGridViewTextBoxColumn.DataPropertyName = "cust_bloodgroup";
            this.custbloodgroupDataGridViewTextBoxColumn.HeaderText = "cust_bloodgroup";
            this.custbloodgroupDataGridViewTextBoxColumn.Name = "custbloodgroupDataGridViewTextBoxColumn";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "customer";
            this.customerBindingSource.DataSource = this.medDataDataSet10;
            // 
            // medDataDataSet10
            // 
            this.medDataDataSet10.DataSetName = "MedDataDataSet10";
            this.medDataDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(177, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "MEDICINE :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(169, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "CUSTOMER :";
            // 
            // medicine_detailTableAdapter
            // 
            this.medicine_detailTableAdapter.ClearBeforeFill = true;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(982, 622);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.DoubleBuffered = true;
            this.Name = "Report";
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private MedDataDataSet9 medDataDataSet9;
        private System.Windows.Forms.BindingSource medicinedetailBindingSource;
        private MedDataDataSet9TableAdapters.Medicine_detailTableAdapter medicine_detailTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn medIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mednameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companynameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expirydateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicinepriceDataGridViewTextBoxColumn;
        private MedDataDataSet10 medDataDataSet10;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private MedDataDataSet10TableAdapters.customerTableAdapter customerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn custidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custaddrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custphoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custbloodgroupDataGridViewTextBoxColumn;
    }
}