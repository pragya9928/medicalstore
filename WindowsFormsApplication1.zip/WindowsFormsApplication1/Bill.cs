﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
            fillcombobox();
            comboboxtwo();
        }

        private void Bill_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet8.Medicine_detail' table. You can move, or remove it, as needed.
            this.medicine_detailTableAdapter1.Fill(this.medDataDataSet8.Medicine_detail);
            // TODO: This line of code loads data into the 'medDataDataSet7.Medicine_detail' table. You can move, or remove it, as needed.
            this.medicine_detailTableAdapter.Fill(this.medDataDataSet7.Medicine_detail);
            // TODO: This line of code loads data into the 'medDataDataSet6.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.medDataDataSet6.customer);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
            string sql = "Select * from customer where cust_name='"+comboBox1.Text+"';";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string cid = myreader.GetInt32(0).ToString();
                    string cname = myreader.GetString(1);
                    string addr = myreader.GetString(2);
                    string cont = myreader.GetString(3);

                    custid.Text = cid;
                    custname.Text = cname;
                    custaddr.Text = addr;
                    custcont.Text = cont;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Printed Successfully");
        }

        public void fillcombobox()
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
            string sql = "Select * from customer";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader=cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string sname = myreader.GetString(1);
                    comboBox1.Items.Add(sname);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       

        public void comboboxtwo()
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
            string sql = "Select * from Medicine_detail";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string snme = myreader.GetString(1);
                    comboBox2.Items.Add(snme);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
            string sql = "Select * from Medicine_detail where med_name='" + comboBox2.Text + "';";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string mname_ = myreader.GetString(1);
                    string cname_ = myreader.GetString(2);
                    string mdate_ = myreader.GetDateTime(3).ToString();
                    string edate_ = myreader.GetDateTime(4).ToString();
                    string price_ = myreader.GetDecimal(5).ToString();

                    mname.Text = mname_;
                    cname.Text = cname_;
                    mdate.Text = mdate_;
                    edate.Text = edate_;
                    price.Text = price_;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            decimal a = Convert.ToDecimal(price.Text);
            decimal b = Convert.ToDecimal(quantity.Text);
            decimal c = a * b;
            tamount.Text = "" + c;

         
                        SqlConnection concust = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
                        concust.Open();
                        SqlCommand cmdcust = new SqlCommand(@"INSERT INTO[dbo].[customer] 
                        (
                            [cust_id], 
                            [cust_name],
                            [cust_addr],
                            [cust_phone],
                            [cust_bloodgroup])
                            VALUES
                            ('" + idtext.Text + "','" + nametext.Text + "','" + addresstext.Text + "','" + contacttext.Text + "','" + bloodtext.Text + "')", concust);
                        cmdcust.ExecuteNonQuery();
                        concust.Close();
                        MessageBox.Show("Registered Successfully.");
           


        }
    }
}
