﻿namespace WindowsFormsApplication1
{
    partial class Medicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Medicine));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.medIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mednameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companynameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expirydateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinedetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet1 = new WindowsFormsApplication1.MedDataDataSet1();
            this.update = new System.Windows.Forms.Button();
            this.insert = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.medname = new System.Windows.Forms.TextBox();
            this.compname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.manufdate = new System.Windows.Forms.TextBox();
            this.expirydate = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.medprice = new System.Windows.Forms.TextBox();
            this.medicine_detailTableAdapter = new WindowsFormsApplication1.MedDataDataSet1TableAdapters.Medicine_detailTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.medid = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.medIdDataGridViewTextBoxColumn,
            this.mednameDataGridViewTextBoxColumn,
            this.companynameDataGridViewTextBoxColumn,
            this.manufacturedateDataGridViewTextBoxColumn,
            this.expirydateDataGridViewTextBoxColumn,
            this.medicinepriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.medicinedetailBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(412, 148);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(643, 233);
            this.dataGridView1.TabIndex = 40;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // medIdDataGridViewTextBoxColumn
            // 
            this.medIdDataGridViewTextBoxColumn.DataPropertyName = "med_Id";
            this.medIdDataGridViewTextBoxColumn.HeaderText = "med_Id";
            this.medIdDataGridViewTextBoxColumn.Name = "medIdDataGridViewTextBoxColumn";
            // 
            // mednameDataGridViewTextBoxColumn
            // 
            this.mednameDataGridViewTextBoxColumn.DataPropertyName = "med_name";
            this.mednameDataGridViewTextBoxColumn.HeaderText = "med_name";
            this.mednameDataGridViewTextBoxColumn.Name = "mednameDataGridViewTextBoxColumn";
            // 
            // companynameDataGridViewTextBoxColumn
            // 
            this.companynameDataGridViewTextBoxColumn.DataPropertyName = "company_name";
            this.companynameDataGridViewTextBoxColumn.HeaderText = "company_name";
            this.companynameDataGridViewTextBoxColumn.Name = "companynameDataGridViewTextBoxColumn";
            // 
            // manufacturedateDataGridViewTextBoxColumn
            // 
            this.manufacturedateDataGridViewTextBoxColumn.DataPropertyName = "manufacture_date";
            this.manufacturedateDataGridViewTextBoxColumn.HeaderText = "manufacture_date";
            this.manufacturedateDataGridViewTextBoxColumn.Name = "manufacturedateDataGridViewTextBoxColumn";
            // 
            // expirydateDataGridViewTextBoxColumn
            // 
            this.expirydateDataGridViewTextBoxColumn.DataPropertyName = "expiry_date";
            this.expirydateDataGridViewTextBoxColumn.HeaderText = "expiry_date";
            this.expirydateDataGridViewTextBoxColumn.Name = "expirydateDataGridViewTextBoxColumn";
            // 
            // medicinepriceDataGridViewTextBoxColumn
            // 
            this.medicinepriceDataGridViewTextBoxColumn.DataPropertyName = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.HeaderText = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.Name = "medicinepriceDataGridViewTextBoxColumn";
            // 
            // medicinedetailBindingSource
            // 
            this.medicinedetailBindingSource.DataMember = "Medicine_detail";
            this.medicinedetailBindingSource.DataSource = this.medDataDataSet1;
            // 
            // medDataDataSet1
            // 
            this.medDataDataSet1.DataSetName = "MedDataDataSet1";
            this.medDataDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.Transparent;
            this.update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(460, 485);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(119, 48);
            this.update.TabIndex = 41;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.button1_Click);
            // 
            // insert
            // 
            this.insert.BackColor = System.Drawing.Color.Transparent;
            this.insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.insert.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.Location = new System.Drawing.Point(302, 485);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(119, 48);
            this.insert.TabIndex = 42;
            this.insert.Text = "INSERT";
            this.insert.UseVisualStyleBackColor = false;
            this.insert.Click += new System.EventHandler(this.insert_Click);
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.Transparent;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.Location = new System.Drawing.Point(608, 485);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(119, 48);
            this.delete.TabIndex = 43;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.show_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(54, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 24);
            this.label2.TabIndex = 28;
            this.label2.Text = "MEDICINE NAME:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 24);
            this.label3.TabIndex = 29;
            this.label3.Text = "COMPANY NAME:";
            // 
            // medname
            // 
            this.medname.Location = new System.Drawing.Point(261, 203);
            this.medname.Name = "medname";
            this.medname.Size = new System.Drawing.Size(102, 22);
            this.medname.TabIndex = 30;
            // 
            // compname
            // 
            this.compname.Location = new System.Drawing.Point(261, 250);
            this.compname.Name = "compname";
            this.compname.Size = new System.Drawing.Size(102, 22);
            this.compname.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 296);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 24);
            this.label4.TabIndex = 32;
            this.label4.Text = "MANUFACTURE DATE:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(88, 349);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 24);
            this.label5.TabIndex = 33;
            this.label5.Text = "EXPIRY DATE:";
            // 
            // manufdate
            // 
            this.manufdate.Location = new System.Drawing.Point(261, 300);
            this.manufdate.Name = "manufdate";
            this.manufdate.Size = new System.Drawing.Size(102, 22);
            this.manufdate.TabIndex = 34;
            // 
            // expirydate
            // 
            this.expirydate.Location = new System.Drawing.Point(261, 349);
            this.expirydate.Name = "expirydate";
            this.expirydate.Size = new System.Drawing.Size(102, 22);
            this.expirydate.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(50, 398);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(191, 24);
            this.label6.TabIndex = 36;
            this.label6.Text = "MEDICINE PRICE:";
            // 
            // medprice
            // 
            this.medprice.Location = new System.Drawing.Point(261, 400);
            this.medprice.Name = "medprice";
            this.medprice.Size = new System.Drawing.Size(102, 22);
            this.medprice.TabIndex = 38;
            // 
            // medicine_detailTableAdapter
            // 
            this.medicine_detailTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(88, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 24);
            this.label1.TabIndex = 44;
            this.label1.Text = "MEDICINE ID:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // medid
            // 
            this.medid.Location = new System.Drawing.Point(261, 155);
            this.medid.Name = "medid";
            this.medid.Size = new System.Drawing.Size(100, 22);
            this.medid.TabIndex = 45;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(757, 485);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 48);
            this.button1.TabIndex = 46;
            this.button1.Text = "SEARCH";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(132, 485);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 48);
            this.button2.TabIndex = 47;
            this.button2.Text = "RESET";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(907, 485);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 48);
            this.button3.TabIndex = 48;
            this.button3.Text = "SHOW ALL";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(413, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(314, 36);
            this.label7.TabIndex = 49;
            this.label7.Text = "MEDICINE DETAILS";
            // 
            // Medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1101, 657);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.medid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.update);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.medprice);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.expirydate);
            this.Controls.Add(this.manufdate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.compname);
            this.Controls.Add(this.medname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Medicine";
            this.Text = "MEDICINE";
            this.Load += new System.EventHandler(this.Medicine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox medname;
        private System.Windows.Forms.TextBox compname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox manufdate;
        private System.Windows.Forms.TextBox expirydate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox medprice;
        private MedDataDataSet1 medDataDataSet1;
        private System.Windows.Forms.BindingSource medicinedetailBindingSource;
        private MedDataDataSet1TableAdapters.Medicine_detailTableAdapter medicine_detailTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn medIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mednameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companynameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expirydateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicinepriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox medid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label7;
    }
}