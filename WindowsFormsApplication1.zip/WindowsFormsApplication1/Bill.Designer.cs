﻿namespace WindowsFormsApplication1
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.billid = new System.Windows.Forms.TextBox();
            this.custaddr = new System.Windows.Forms.TextBox();
            this.custcont = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet6 = new WindowsFormsApplication1.MedDataDataSet6();
            this.customerTableAdapter = new WindowsFormsApplication1.MedDataDataSet6TableAdapters.customerTableAdapter();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.medDataDataSet1 = new WindowsFormsApplication1.MedDataDataSet();
            this.label14 = new System.Windows.Forms.Label();
            this.medicinedetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet7 = new WindowsFormsApplication1.MedDataDataSet7();
            this.medicine_detailTableAdapter = new WindowsFormsApplication1.MedDataDataSet7TableAdapters.Medicine_detailTableAdapter();
            this.mname = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.medIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mednameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicinedetailBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet8 = new WindowsFormsApplication1.MedDataDataSet8();
            this.medicine_detailTableAdapter1 = new WindowsFormsApplication1.MedDataDataSet8TableAdapters.Medicine_detailTableAdapter();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cname = new System.Windows.Forms.TextBox();
            this.edate = new System.Windows.Forms.TextBox();
            this.mdate = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tamount = new System.Windows.Forms.TextBox();
            this.quantity = new System.Windows.Forms.TextBox();
            this.price = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.custid = new System.Windows.Forms.TextBox();
            this.custname = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet8)).BeginInit();
            this.SuspendLayout();
            // 
            // billid
            // 
            this.billid.Location = new System.Drawing.Point(241, 145);
            this.billid.Name = "billid";
            this.billid.Size = new System.Drawing.Size(100, 22);
            this.billid.TabIndex = 43;
            // 
            // custaddr
            // 
            this.custaddr.Location = new System.Drawing.Point(609, 226);
            this.custaddr.Name = "custaddr";
            this.custaddr.Size = new System.Drawing.Size(112, 22);
            this.custaddr.TabIndex = 39;
            // 
            // custcont
            // 
            this.custcont.Location = new System.Drawing.Point(837, 225);
            this.custcont.Name = "custcont";
            this.custcont.Size = new System.Drawing.Size(100, 22);
            this.custcont.TabIndex = 38;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.BackColor = System.Drawing.Color.Transparent;
            this.Label13.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(137, 145);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(87, 21);
            this.Label13.TabIndex = 36;
            this.Label13.Text = "BILL ID :";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.BackColor = System.Drawing.Color.Transparent;
            this.Label12.Font = new System.Drawing.Font("Tahoma", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(583, 79);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(80, 34);
            this.Label12.TabIndex = 35;
            this.Label12.Text = "BILL";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(229, 152);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(0, 17);
            this.Label7.TabIndex = 30;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(727, 227);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(87, 21);
            this.Label4.TabIndex = 27;
            this.Label4.Text = "Contact :";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(494, 227);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(90, 21);
            this.Label3.TabIndex = 26;
            this.Label3.Text = "Address :";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(135, 197);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(171, 21);
            this.Label2.TabIndex = 25;
            this.Label2.Text = "CUSTOMER NAME :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(329, 194);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(198, 24);
            this.comboBox1.TabIndex = 49;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "customer";
            this.customerBindingSource.DataSource = this.medDataDataSet6;
            // 
            // medDataDataSet6
            // 
            this.medDataDataSet6.DataSetName = "MedDataDataSet6";
            this.medDataDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(516, 141);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(147, 28);
            this.dateTimePicker1.TabIndex = 50;
            // 
            // medDataDataSet1
            // 
            this.medDataDataSet1.DataSetName = "MedDataDataSet";
            this.medDataDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(137, 308);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(169, 21);
            this.label14.TabIndex = 51;
            this.label14.Text = "MEDICINE NAME : ";
            // 
            // medicinedetailBindingSource
            // 
            this.medicinedetailBindingSource.DataMember = "Medicine_detail";
            this.medicinedetailBindingSource.DataSource = this.medDataDataSet7;
            // 
            // medDataDataSet7
            // 
            this.medDataDataSet7.DataSetName = "MedDataDataSet7";
            this.medDataDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicine_detailTableAdapter
            // 
            this.medicine_detailTableAdapter.ClearBeforeFill = true;
            // 
            // mname
            // 
            this.mname.Location = new System.Drawing.Point(540, 305);
            this.mname.Name = "mname";
            this.mname.Size = new System.Drawing.Size(154, 22);
            this.mname.TabIndex = 53;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.medIdDataGridViewTextBoxColumn,
            this.mednameDataGridViewTextBoxColumn,
            this.medicinepriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.medicinedetailBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(104, 346);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(341, 150);
            this.dataGridView1.TabIndex = 54;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // medIdDataGridViewTextBoxColumn
            // 
            this.medIdDataGridViewTextBoxColumn.DataPropertyName = "med_Id";
            this.medIdDataGridViewTextBoxColumn.HeaderText = "med_Id";
            this.medIdDataGridViewTextBoxColumn.Name = "medIdDataGridViewTextBoxColumn";
            // 
            // mednameDataGridViewTextBoxColumn
            // 
            this.mednameDataGridViewTextBoxColumn.DataPropertyName = "med_name";
            this.mednameDataGridViewTextBoxColumn.HeaderText = "med_name";
            this.mednameDataGridViewTextBoxColumn.Name = "mednameDataGridViewTextBoxColumn";
            // 
            // medicinepriceDataGridViewTextBoxColumn
            // 
            this.medicinepriceDataGridViewTextBoxColumn.DataPropertyName = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.HeaderText = "medicine_price";
            this.medicinepriceDataGridViewTextBoxColumn.Name = "medicinepriceDataGridViewTextBoxColumn";
            // 
            // medicinedetailBindingSource1
            // 
            this.medicinedetailBindingSource1.DataMember = "Medicine_detail";
            this.medicinedetailBindingSource1.DataSource = this.medDataDataSet8;
            // 
            // medDataDataSet8
            // 
            this.medDataDataSet8.DataSetName = "MedDataDataSet8";
            this.medDataDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicine_detailTableAdapter1
            // 
            this.medicine_detailTableAdapter1.ClearBeforeFill = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(434, 145);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 21);
            this.label15.TabIndex = 55;
            this.label15.Text = "DATE :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(702, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 21);
            this.label16.TabIndex = 56;
            this.label16.Text = "TIME :";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker2.Location = new System.Drawing.Point(783, 141);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(123, 28);
            this.dateTimePicker2.TabIndex = 57;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(490, 349);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(167, 21);
            this.label17.TabIndex = 58;
            this.label17.Text = "COMPANY NAME : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(490, 405);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(135, 21);
            this.label18.TabIndex = 59;
            this.label18.Text = "EXPIRY DATE :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(490, 377);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(202, 21);
            this.label19.TabIndex = 60;
            this.label19.Text = "MANUFACTURE DATE :";
            // 
            // cname
            // 
            this.cname.Location = new System.Drawing.Point(731, 350);
            this.cname.Name = "cname";
            this.cname.Size = new System.Drawing.Size(100, 22);
            this.cname.TabIndex = 61;
            // 
            // edate
            // 
            this.edate.Location = new System.Drawing.Point(731, 406);
            this.edate.Name = "edate";
            this.edate.Size = new System.Drawing.Size(100, 22);
            this.edate.TabIndex = 63;
            // 
            // mdate
            // 
            this.mdate.Location = new System.Drawing.Point(731, 378);
            this.mdate.Name = "mdate";
            this.mdate.Size = new System.Drawing.Size(100, 22);
            this.mdate.TabIndex = 62;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(516, 466);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 57);
            this.button1.TabIndex = 64;
            this.button1.Text = "ADD ITEM";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(665, 466);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 57);
            this.button2.TabIndex = 65;
            this.button2.Text = "REMOVE ITEM";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // tamount
            // 
            this.tamount.Location = new System.Drawing.Point(992, 466);
            this.tamount.Name = "tamount";
            this.tamount.Size = new System.Drawing.Size(100, 22);
            this.tamount.TabIndex = 71;
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(995, 381);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(100, 22);
            this.quantity.TabIndex = 70;
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(995, 353);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(100, 22);
            this.price.TabIndex = 69;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(865, 381);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(111, 21);
            this.label20.TabIndex = 68;
            this.label20.Text = "QUANTITY :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(819, 467);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(157, 21);
            this.label21.TabIndex = 67;
            this.label21.Text = "TOTAL AMOUNT :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(865, 353);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 21);
            this.label22.TabIndex = 66;
            this.label22.Text = "PRICE : ";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(854, 577);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 42);
            this.button3.TabIndex = 72;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(965, 577);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 42);
            this.button4.TabIndex = 73;
            this.button4.Text = " PRINT";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(135, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 21);
            this.label1.TabIndex = 74;
            this.label1.Text = "CUSTOMER ID :";
            // 
            // custid
            // 
            this.custid.Location = new System.Drawing.Point(305, 226);
            this.custid.Name = "custid";
            this.custid.Size = new System.Drawing.Size(154, 22);
            this.custid.TabIndex = 75;
            // 
            // custname
            // 
            this.custname.Location = new System.Drawing.Point(540, 194);
            this.custname.Name = "custname";
            this.custname.Size = new System.Drawing.Size(168, 22);
            this.custname.TabIndex = 76;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(329, 305);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(198, 24);
            this.comboBox2.TabIndex = 77;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged_1);
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1214, 708);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.custname);
            this.Controls.Add(this.custid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tamount);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.price);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.edate);
            this.Controls.Add(this.mdate);
            this.Controls.Add(this.cname);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.mname);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.billid);
            this.Controls.Add(this.custaddr);
            this.Controls.Add(this.custcont);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Name = "Bill";
            this.Text = "BILL";
            this.Load += new System.EventHandler(this.Bill_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinedetailBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox billid;
        internal System.Windows.Forms.TextBox custaddr;
        internal System.Windows.Forms.TextBox custcont;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private MedDataDataSet6 medDataDataSet6;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private MedDataDataSet6TableAdapters.customerTableAdapter customerTableAdapter;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MedDataDataSet medDataDataSet1;
        private System.Windows.Forms.Label label14;
        private MedDataDataSet7 medDataDataSet7;
        private System.Windows.Forms.BindingSource medicinedetailBindingSource;
        private MedDataDataSet7TableAdapters.Medicine_detailTableAdapter medicine_detailTableAdapter;
        private System.Windows.Forms.TextBox mname;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MedDataDataSet8 medDataDataSet8;
        private System.Windows.Forms.BindingSource medicinedetailBindingSource1;
        private MedDataDataSet8TableAdapters.Medicine_detailTableAdapter medicine_detailTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn medIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mednameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicinepriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox cname;
        private System.Windows.Forms.TextBox edate;
        private System.Windows.Forms.TextBox mdate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tamount;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.TextBox price;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox custid;
        private System.Windows.Forms.TextBox custname;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}