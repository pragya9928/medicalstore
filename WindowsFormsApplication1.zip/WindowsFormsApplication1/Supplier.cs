﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Supplier : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
        SqlCommand cmd;
        SqlDataAdapter adapt;


        public Supplier()
        {
            InitializeComponent();
            DisplayData();
        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet4.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter.Fill(this.medDataDataSet4.Supplier);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Utilities.ResetAllControls(this);
        }

        public class Utilities
        {
            public static void ResetAllControls(Control form)
            {
                foreach (Control control in form.Controls)
                {
                    if (control is TextBox)
                    {
                        TextBox textbox = (TextBox)control;
                        textbox.Text = null;
                    }

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (supid.Text == "" || supname.Text == "" || supadd.Text == "" || supmob.Text == "" || agname.Text == "" || agadd.Text == "" || agcontact.Text == "" || contper.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("insert into Supplier(sup_Id,sup_name,sup_address,sup_mobile,agency_name,agency_address,agency_contact,contact_person_name) values(@supid,@supname,@supaddress,@supmobile,@agencyname,@agencyaddress,@agencycontact,@contactperson)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@supid", supid.Text);
                    cmd.Parameters.AddWithValue("@supname", supname.Text);
                    cmd.Parameters.AddWithValue("@supaddress", supadd.Text);
                    cmd.Parameters.AddWithValue("@supmobile", supmob.Text);
                    cmd.Parameters.AddWithValue("@agencyname", agname.Text);
                    cmd.Parameters.AddWithValue("@agencyaddress", agadd.Text);
                    cmd.Parameters.AddWithValue("@agencycontact", agcontact.Text);
                    cmd.Parameters.AddWithValue("@contactperson", contper.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("RECORD INSERTED SUCCESSFULLY");
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE PROVIDE DETAILS");
            }
        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Supplier", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void ClearData()
        {
            supid.Text = "";
            supname.Text = "";
            supadd.Text = "";
            supmob.Text = "";
            agname.Text = "";
            agadd.Text = "";
            agcontact.Text = "";
            contper.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (supid.Text == "" || supname.Text == "" || supadd.Text == "" || supmob.Text == "" || agname.Text == "" || agadd.Text == "" || agcontact.Text == "" || contper.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("update Medicine_detail set sup_Id=@supid,sup_name=@supname,sup_address=@supaddress,sup_mobile=@supmobile,agency_name=@agencyname,agency_address=@agencyaddress,agency_contact=@agencycontact,contact_person_name=@contactperson", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@supid", supid.Text);
                    cmd.Parameters.AddWithValue("@supname", supname.Text);
                    cmd.Parameters.AddWithValue("@supaddress", supadd.Text);
                    cmd.Parameters.AddWithValue("@supmobile", supmob.Text);
                    cmd.Parameters.AddWithValue("@agencyname", agname.Text);
                    cmd.Parameters.AddWithValue("@agencyaddress", agadd.Text);
                    cmd.Parameters.AddWithValue("@agencycontact", agcontact.Text);
                    cmd.Parameters.AddWithValue("@contactperson", contper.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");
                    con.Close();
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO UPDATE");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            supid.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    //Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            supname.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            supadd.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            supmob.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            agname.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            agadd.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            agcontact.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            contper.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                if (supid.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("delete Supplier where sup_Id=@supid", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@supid", supid.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("RECORD DELETED SUCCESSFULLY");
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO DELETE");
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Supplier where agency_name='" + agname.Text + "'", con);
            DataSet ds = new DataSet();
            sda.Fill(ds, "Suppliers");
            dataGridView1.DataSource = ds.Tables["Suppliers"];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DisplayData();
        }


    }
}
