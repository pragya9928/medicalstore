﻿namespace WindowsFormsApplication1
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supplier));
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.supIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supaddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supmobileDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.agencynameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.agencyaddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.agencycontactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactpersonnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medDataDataSet4 = new WindowsFormsApplication1.MedDataDataSet4();
            this.supplierTableAdapter = new WindowsFormsApplication1.MedDataDataSet4TableAdapters.SupplierTableAdapter();
            this.button5 = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.supid = new System.Windows.Forms.TextBox();
            this.supname = new System.Windows.Forms.TextBox();
            this.supadd = new System.Windows.Forms.TextBox();
            this.supmob = new System.Windows.Forms.TextBox();
            this.agname = new System.Windows.Forms.TextBox();
            this.agadd = new System.Windows.Forms.TextBox();
            this.agcontact = new System.Windows.Forms.TextBox();
            this.contper = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(444, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "SUPPLIER";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supIdDataGridViewTextBoxColumn,
            this.supnameDataGridViewTextBoxColumn,
            this.supaddressDataGridViewTextBoxColumn,
            this.supmobileDataGridViewTextBoxColumn,
            this.agencynameDataGridViewTextBoxColumn,
            this.agencyaddressDataGridViewTextBoxColumn,
            this.agencycontactDataGridViewTextBoxColumn,
            this.contactpersonnameDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.supplierBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(96, 122);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(842, 150);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // supIdDataGridViewTextBoxColumn
            // 
            this.supIdDataGridViewTextBoxColumn.DataPropertyName = "sup_Id";
            this.supIdDataGridViewTextBoxColumn.HeaderText = "sup_Id";
            this.supIdDataGridViewTextBoxColumn.Name = "supIdDataGridViewTextBoxColumn";
            // 
            // supnameDataGridViewTextBoxColumn
            // 
            this.supnameDataGridViewTextBoxColumn.DataPropertyName = "sup_name";
            this.supnameDataGridViewTextBoxColumn.HeaderText = "sup_name";
            this.supnameDataGridViewTextBoxColumn.Name = "supnameDataGridViewTextBoxColumn";
            // 
            // supaddressDataGridViewTextBoxColumn
            // 
            this.supaddressDataGridViewTextBoxColumn.DataPropertyName = "sup_address";
            this.supaddressDataGridViewTextBoxColumn.HeaderText = "sup_address";
            this.supaddressDataGridViewTextBoxColumn.Name = "supaddressDataGridViewTextBoxColumn";
            // 
            // supmobileDataGridViewTextBoxColumn
            // 
            this.supmobileDataGridViewTextBoxColumn.DataPropertyName = "sup_mobile";
            this.supmobileDataGridViewTextBoxColumn.HeaderText = "sup_mobile";
            this.supmobileDataGridViewTextBoxColumn.Name = "supmobileDataGridViewTextBoxColumn";
            // 
            // agencynameDataGridViewTextBoxColumn
            // 
            this.agencynameDataGridViewTextBoxColumn.DataPropertyName = "agency_name";
            this.agencynameDataGridViewTextBoxColumn.HeaderText = "agency_name";
            this.agencynameDataGridViewTextBoxColumn.Name = "agencynameDataGridViewTextBoxColumn";
            // 
            // agencyaddressDataGridViewTextBoxColumn
            // 
            this.agencyaddressDataGridViewTextBoxColumn.DataPropertyName = "agency_address";
            this.agencyaddressDataGridViewTextBoxColumn.HeaderText = "agency_address";
            this.agencyaddressDataGridViewTextBoxColumn.Name = "agencyaddressDataGridViewTextBoxColumn";
            // 
            // agencycontactDataGridViewTextBoxColumn
            // 
            this.agencycontactDataGridViewTextBoxColumn.DataPropertyName = "agency_contact";
            this.agencycontactDataGridViewTextBoxColumn.HeaderText = "agency_contact";
            this.agencycontactDataGridViewTextBoxColumn.Name = "agencycontactDataGridViewTextBoxColumn";
            // 
            // contactpersonnameDataGridViewTextBoxColumn
            // 
            this.contactpersonnameDataGridViewTextBoxColumn.DataPropertyName = "contact_person_name";
            this.contactpersonnameDataGridViewTextBoxColumn.HeaderText = "contact_person_name";
            this.contactpersonnameDataGridViewTextBoxColumn.Name = "contactpersonnameDataGridViewTextBoxColumn";
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.medDataDataSet4;
            // 
            // medDataDataSet4
            // 
            this.medDataDataSet4.DataSetName = "MedDataDataSet4";
            this.medDataDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(821, 514);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 55);
            this.button5.TabIndex = 24;
            this.button5.Text = "SHOW ALL";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.Transparent;
            this.search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.search.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Location = new System.Drawing.Point(677, 514);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(112, 55);
            this.search.TabIndex = 23;
            this.search.Text = "SEARCH";
            this.search.UseVisualStyleBackColor = false;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(532, 514);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 55);
            this.button4.TabIndex = 22;
            this.button4.Text = "DELETE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(376, 514);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 55);
            this.button3.TabIndex = 21;
            this.button3.Text = "UPDATE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(111, 514);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 55);
            this.button2.TabIndex = 20;
            this.button2.Text = "RESET";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(241, 514);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 55);
            this.button1.TabIndex = 19;
            this.button1.Text = "INSERT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(144, 310);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 21);
            this.label2.TabIndex = 25;
            this.label2.Text = "SUPPLIER ID :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(144, 354);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 21);
            this.label3.TabIndex = 26;
            this.label3.Text = "SUPPLIER NAME :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(144, 400);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 21);
            this.label4.TabIndex = 27;
            this.label4.Text = "SUPPPLIER ADDRESS :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(147, 443);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 21);
            this.label5.TabIndex = 28;
            this.label5.Text = "SUPPLIER MOBILE :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(567, 446);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 21);
            this.label6.TabIndex = 32;
            this.label6.Text = "CONTACT PERSON :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(567, 400);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(176, 21);
            this.label7.TabIndex = 31;
            this.label7.Text = "AGENCY CONTACT :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(567, 355);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 21);
            this.label8.TabIndex = 30;
            this.label8.Text = "AGENCY ADDRESS :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(567, 311);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(146, 21);
            this.label9.TabIndex = 29;
            this.label9.Text = "AGENCY NAME :";
            // 
            // supid
            // 
            this.supid.Location = new System.Drawing.Point(376, 313);
            this.supid.Name = "supid";
            this.supid.Size = new System.Drawing.Size(100, 22);
            this.supid.TabIndex = 33;
            // 
            // supname
            // 
            this.supname.Location = new System.Drawing.Point(376, 355);
            this.supname.Name = "supname";
            this.supname.Size = new System.Drawing.Size(100, 22);
            this.supname.TabIndex = 34;
            // 
            // supadd
            // 
            this.supadd.Location = new System.Drawing.Point(376, 399);
            this.supadd.Name = "supadd";
            this.supadd.Size = new System.Drawing.Size(100, 22);
            this.supadd.TabIndex = 35;
            // 
            // supmob
            // 
            this.supmob.Location = new System.Drawing.Point(376, 442);
            this.supmob.Name = "supmob";
            this.supmob.Size = new System.Drawing.Size(100, 22);
            this.supmob.TabIndex = 36;
            // 
            // agname
            // 
            this.agname.Location = new System.Drawing.Point(773, 312);
            this.agname.Name = "agname";
            this.agname.Size = new System.Drawing.Size(100, 22);
            this.agname.TabIndex = 37;
            // 
            // agadd
            // 
            this.agadd.Location = new System.Drawing.Point(773, 356);
            this.agadd.Name = "agadd";
            this.agadd.Size = new System.Drawing.Size(100, 22);
            this.agadd.TabIndex = 38;
            // 
            // agcontact
            // 
            this.agcontact.Location = new System.Drawing.Point(773, 401);
            this.agcontact.Name = "agcontact";
            this.agcontact.Size = new System.Drawing.Size(100, 22);
            this.agcontact.TabIndex = 39;
            // 
            // contper
            // 
            this.contper.Location = new System.Drawing.Point(773, 445);
            this.contper.Name = "contper";
            this.contper.Size = new System.Drawing.Size(100, 22);
            this.contper.TabIndex = 40;
            // 
            // Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1027, 629);
            this.Controls.Add(this.contper);
            this.Controls.Add(this.agcontact);
            this.Controls.Add(this.agadd);
            this.Controls.Add(this.agname);
            this.Controls.Add(this.supmob);
            this.Controls.Add(this.supadd);
            this.Controls.Add(this.supname);
            this.Controls.Add(this.supid);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.search);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Supplier";
            this.Text = "SUPPLIER";
            this.Load += new System.EventHandler(this.Supplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medDataDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MedDataDataSet4 medDataDataSet4;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private MedDataDataSet4TableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supaddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supmobileDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn agencynameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn agencyaddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn agencycontactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactpersonnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox supid;
        private System.Windows.Forms.TextBox supname;
        private System.Windows.Forms.TextBox supadd;
        private System.Windows.Forms.TextBox supmob;
        private System.Windows.Forms.TextBox agname;
        private System.Windows.Forms.TextBox agadd;
        private System.Windows.Forms.TextBox agcontact;
        private System.Windows.Forms.TextBox contper;

    }
}