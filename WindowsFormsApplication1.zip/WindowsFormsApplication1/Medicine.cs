﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Medicine : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
        SqlCommand cmd;
        SqlDataAdapter adapt;

        //int ID = 0;

        public Medicine()
        {
            InitializeComponent();
            DisplayData();
        }

        private void button1_Click(object sender, EventArgs e) //UPDATE
        {
            try
            {
                if (medid.Text == "" || medname.Text == "" || compname.Text == "" || manufdate.Text == "" || expirydate.Text == "" || medprice.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("update Medicine_detail set med_Id=@medid,med_name=@medname,company_name=@companyname,manufacture_date=@manudate,expiry_date=@exdate,medicine_price=@medprice", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@medid", medid.Text);
                    cmd.Parameters.AddWithValue("@medname", medname.Text);
                    cmd.Parameters.AddWithValue("@companyname", compname.Text);
                    cmd.Parameters.AddWithValue("@manudate", manufdate.Text);
                    cmd.Parameters.AddWithValue("@exdate", expirydate.Text);
                    cmd.Parameters.AddWithValue("@medprice", medprice.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");
                    con.Close();
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO UPDATE");
            }
        }

        private void show_Click(object sender, EventArgs e) //DELETE
        {
            try
            {

                if (medid.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("delete Medicine_detail where med_Id=@medid", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@medid", medid.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("RECORD DELETED SUCCESSFULLY");
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO DELETE");
            }
        }

        private void Medicine_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet1.Medicine_detail' table. You can move, or remove it, as needed.
            this.medicine_detailTableAdapter.Fill(this.medDataDataSet1.Medicine_detail);

        }

        private void insert_Click(object sender, EventArgs e) //INSERT
        {
            try
            {
                if (medid.Text == "" || medname.Text == "" || compname.Text == "" || manufdate.Text == "" || expirydate.Text == "" || medprice.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("insert into Medicine_detail(med_Id,med_name,company_name,manufacture_date,expiry_date,medicine_price) values(@medid,@medname,@companyname,@manudate,@exdate,@medprice)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@medid", medid.Text);
                    cmd.Parameters.AddWithValue("@medname", medname.Text);
                    cmd.Parameters.AddWithValue("@companyname", compname.Text);
                    cmd.Parameters.AddWithValue("@manudate", manufdate.Text);
                    cmd.Parameters.AddWithValue("@exdate", expirydate.Text);
                    cmd.Parameters.AddWithValue("@medprice", medprice.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("RECORD INSERTED SUCCESSFULLY");
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE PROVIDE DETAILS");
            }
        }
        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt=new SqlDataAdapter("select * from Medicine_detail",con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void ClearData()
        {
            medname.Text = "";
            compname.Text = "";
            manufdate.Text = "";
            expirydate.Text = "";
            medprice.Text = "";
            medid.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            medid.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    //Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            medname.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            compname.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            manufdate.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            expirydate.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            medprice.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Medicine_detail where med_name='" + medname.Text + "'", con);
            DataSet ds = new DataSet();
            sda.Fill(ds, "Medicine_details");
            dataGridView1.DataSource = ds.Tables["Medicine_details"];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Utilities.ResetAllControls(this);
        }

        public class Utilities
        {
            public static void ResetAllControls(Control form)
            {
                foreach (Control control in form.Controls)
                {
                    if (control is TextBox)
                    {
                        TextBox textbox = (TextBox)control;
                        textbox.Text = null;
                    }

                }
            }
        }

    }
}
