﻿CREATE TABLE [dbo].[customer] (
    [cust_id]         INT          NOT NULL,
    [cust_name]       VARCHAR (50) NOT NULL,
    [cust_addr]       VARCHAR (50) NOT NULL,
    [cust_phone]      VARCHAR(50)          NOT NULL,
    [cust_bloodgroup] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_customer] PRIMARY KEY CLUSTERED ([cust_id] ASC)
);

