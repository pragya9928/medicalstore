﻿create table bill_details
(
	bill_id int primary key,
	bill_date date,
	bill_time time,
	cust_id int references customer(cust_id),
	cust_name int references customer(cust_id),
	med_name int references Medicine_detail(med_Id),
	medicine_price int references Medicine_detail(med_Id),
	quantity_of_each_med int,
	total_amount decimal(10,2)
)
select * from bill_details