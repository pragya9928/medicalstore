﻿create table stock
(
	stock_id int primary key,
	qtyinhand int,
	med_Id int references Medicine_detail(med_Id),
	sup_Id int references Supplier(sup_Id)
)

select * from stock