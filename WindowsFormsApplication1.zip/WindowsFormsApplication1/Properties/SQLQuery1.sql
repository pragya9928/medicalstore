﻿create table stock
(
 stock_id int primary key,
 qtyinhand int,
 med_Id int references Medicine_detail(med_ID)
)

select * from stock