﻿create table order_detail
(
	order_id int primary key,
	order_date date,
	order_time time,
	sup_Id int references Supplier(sup_Id),
	med_Id int references Medicine_detail(med_ID),
	quantity int,
	total_price decimal(10,2)
)