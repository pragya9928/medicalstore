﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Report_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet10.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.medDataDataSet10.customer);
            // TODO: This line of code loads data into the 'medDataDataSet9.Medicine_detail' table. You can move, or remove it, as needed.
            this.medicine_detailTableAdapter.Fill(this.medDataDataSet9.Medicine_detail);

        }
    }
}
