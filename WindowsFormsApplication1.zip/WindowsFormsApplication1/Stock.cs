﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Stock : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
        SqlCommand cmd;
        SqlDataAdapter adapt;


        public Stock()
        {
            InitializeComponent();
        }

        private void Stock_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet5.stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.medDataDataSet5.stock);

        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from stock", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void ClearData()
        {
            stockid.Text = "";
            quantity.Text = "";
            medid.Text = "";
            supid.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockid.Text == "" || quantity.Text == "" || medid.Text == "" || supid.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("insert into stock(stock_id,qtyinhand,med_Id,sup_Id) values(@stockid,@qty,@medid,@supid)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@stockid", stockid.Text);
                    cmd.Parameters.AddWithValue("@qty", quantity.Text);
                    cmd.Parameters.AddWithValue("@medid", medid.Text);
                    cmd.Parameters.AddWithValue("@supid", supid.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("RECORD INSERTED SUCCESSFULLY");
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE PROVIDE DETAILS");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockid.Text == "" || quantity.Text == "" || medid.Text == "" || supid.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    cmd = new SqlCommand("update stock set stock_id=@stockid,qtyinhand=@qty,med_Id=@medid,sup_Id=@supid", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@stockid", stockid.Text);
                    cmd.Parameters.AddWithValue("@qty", quantity.Text);
                    cmd.Parameters.AddWithValue("@medid", medid.Text);
                    cmd.Parameters.AddWithValue("@supid", supid.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");
                    con.Close();
                    DisplayData();
                    ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO UPDATE");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            stockid.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            quantity.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            medid.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            supid.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
    }
}
