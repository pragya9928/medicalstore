﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            customer a = new customer();
            a.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Bill b = new Bill();
            b.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Medicine m = new Medicine();
            m.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Stock s = new Stock();
            s.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            Supplier z = new Supplier();
            z.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Report r = new Report();
            r.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        
    }
}
