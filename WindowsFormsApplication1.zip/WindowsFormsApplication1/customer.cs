﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApplication1
{
    public partial class customer : Form
    {

        SqlConnection concust = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
        SqlCommand cmdcust;

        public customer()
        {
            InitializeComponent();
            DisplayData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtext.Text == "" || nametext.Text == "" || addresstext.Text == "" || contacttext.Text == "" || bloodtext.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    try
                    {
                        SqlConnection concust = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
                        concust.Open();
                        SqlCommand cmdcust = new SqlCommand(@"INSERT INTO[dbo].[customer] 
                        (
                            [cust_id], 
                            [cust_name],
                            [cust_addr],
                            [cust_phone],
                            [cust_bloodgroup])
                            VALUES
                            ('" + idtext.Text + "','" + nametext.Text + "','" + addresstext.Text + "','" + contacttext.Text + "','" + bloodtext.Text + "')", concust);
                        cmdcust.ExecuteNonQuery();
                        concust.Close();
                        MessageBox.Show("Registered Successfully.");
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("ERROR : Sorry, the entered data is incorrect.");
                    }
                }
                DisplayData();
                //ClearData();
            }

            catch (Exception)
            {
                MessageBox.Show("Error! Fill all details!");
                //MessageBox.Show("Not Registered", ex.Message.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Utilities.ResetAllControls(this);
        }

        public class Utilities
        {
            public static void ResetAllControls(Control form)
            {
                foreach (Control control in form.Controls)
                {
                    if (control is TextBox)
                    {
                        TextBox textbox = (TextBox)control;
                        textbox.Text = null;
                    }

                }
            }
        }

        private void customer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medDataDataSet2.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.medDataDataSet2.customer);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            idtext.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    
            nametext.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            addresstext.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            contacttext.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            bloodtext.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            
        }
        private void DisplayData()
        {
            SqlConnection concust = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=D:\\Visual Studio 12\\medproject\\WindowsFormsApplication1\\WindowsFormsApplication1\\MedData.mdf;Integrated Security=True;Connect Timeout=30;");
            concust.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from customer", concust);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            concust.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmdcust = new SqlCommand("update customer set cust_id=@cid,cust_name=@cname,cust_addr=@caddr,cust_phone=@cphone,cust_bloodgroup=@cblood where(cust_id=@cid)", concust);
            concust.Open();
            cmdcust.Parameters.AddWithValue("@cid", idtext.Text);
            cmdcust.Parameters.AddWithValue("@cname", nametext.Text);
            cmdcust.Parameters.AddWithValue("@caddr", addresstext.Text);
            cmdcust.Parameters.AddWithValue("@cphone", contacttext.Text);
            cmdcust.Parameters.AddWithValue("@cblood", bloodtext.Text);
            cmdcust.ExecuteNonQuery();
            MessageBox.Show("Record Updated Successfully");
            concust.Close();
            DisplayData();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                if (idtext.Text == "")
                {
                    throw new Exception();
                }
                else
                {
                    SqlCommand cmdcust = new SqlCommand("delete customer where cust_id=@cid", concust);
                    concust.Open();
                    cmdcust.Parameters.AddWithValue("@cid", idtext.Text);
                    cmdcust.ExecuteNonQuery();
                    concust.Close();
                    MessageBox.Show("RECORD DELETED SUCCESSFULLY");
                    DisplayData();
                    //ClearData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("PLEASE SELECT RECORD TO DELETE");
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from customer where cust_name='" + nametext.Text + "'",concust);
            DataSet ds = new DataSet();
            sda.Fill(ds,"customer");
            dataGridView1.DataSource = ds.Tables["customer"];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DisplayData();
        }
        //private void ClearData()
        //{
        //    idtext.Text = "";
        //    nametext.Text = "";
        //    addresstext.Text = "";
        //    contacttext.Text = "";
        //    bloodtext.Text = "";
        //}

        }
    }